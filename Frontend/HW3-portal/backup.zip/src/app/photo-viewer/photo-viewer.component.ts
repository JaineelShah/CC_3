import { Component, ViewEncapsulation } from '@angular/core';

@Component({
  selector: 'app-photo-viewer',
  templateUrl: './photo-viewer.component.html',
  styleUrls: ['./photo-viewer.component.scss'],
  encapsulation : ViewEncapsulation.None,
})
export class PhotoViewerComponent {
  // method search that calls the API
  searchText: string = '';
  search() {
    console.log(`User entered: ${this.searchText}`);
  }
}


